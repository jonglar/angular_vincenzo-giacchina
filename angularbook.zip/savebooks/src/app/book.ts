export class Book {
  nome:string;
  note:string;
  pages: number;
  currentPage: number;
}
