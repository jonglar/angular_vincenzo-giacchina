/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MyMapDirective } from './my-map.directive';

describe('MyMapDirective', () => {
  it('should create an instance', () => {
    const directive = new MyMapDirective();
    expect(directive).toBeTruthy();
  });
});
